        <div class="span3">
          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Select Options</li>

              <li><a href="add_slider_image.php">Add Slider Image</a></li>
              <li><a href="add_category_slider_image.php">Add Category Slider Image</a></li>
              <li><a href="add_background_image.php">Add Background Image</a></li>
              <li><a href="add_sub_category.php">Add Sub Category</a></li>
              <li><a href="add_new_product.php">Add New Product</a></li>
              <li><a href="add_brand.php">Add New Brand</a></li>
              <li><a href="add_new_type.php">Add New Type</a></li>
              <li><a href="add_discount.php">Add Discount</a></li>
              <li><a href="add_quantity.php">Add Quantity</a></li>
              <li><a href="upload_image.php">Upload Image</a></li>
              <li><a href="add_random_details.php">ADD Details</a></li>
              <li><a href="add_advertisement.php">ADD Advertisement</a></li>
              </br>
              <li><a href="add_favourites_product.php">Add Favourites Product</a></li>
              
             
            
            </ul>
         </div><!--/.well -->
        </div><!--/span-->
        