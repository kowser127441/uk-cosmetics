        <div class="span3">
          <div class="well sidebar-nav">
            <ul class="nav nav-list">
              <li class="nav-header">Select Options</li>

              
              <li><a href="view_products.php">View Products</a></li>
              <li><a href="view_clients.php">View Clients</a></li>
              <li><a href="view_discount.php">View Discount</a></li>
              <li><a href="view_favourites_product.php">View Favourite Product</a></li>
                            <li><a href="view_reviews.php">View Reviews</a></li>
              
            
            </ul>
         </div><!--/.well -->
        </div><!--/span-->