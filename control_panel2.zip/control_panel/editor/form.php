<html>
<head>

</head>

<body>
<form action="test.php" method="post" enctype="application/x-www-form-urlencoded">

<textarea name="iframe" ></textarea>

<input type="submit" value="Submit" />


</form>


</body>



</html>