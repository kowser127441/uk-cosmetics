![Screenshot](http://stracker-phil.github.com/Floating-Tools/images/example-2.png)

-----

Floating-Tools
==============

Plugin for CKEditor to show an floating toolbar for quick access to formatting functions!


Documentation
=============

Also have a look at the project-page at
http://stracker-phil.github.com/Floating-Tools/

-----

Philipp Stracker
http://www.stracker.net
