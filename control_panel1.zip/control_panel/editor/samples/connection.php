 <?php
$con = mysql_connect("localhost","abhworl4_kawser","kawser127441");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("abhworl4_uk_cosmetics", $con);


?>
