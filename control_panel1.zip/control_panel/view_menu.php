

<ul class="navigation">
    <li style=" margin-left:70px;"><a href="admin.php">&nbsp;&nbsp;Home&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
    <li><a href="add.php" >&nbsp;&nbsp;Add&nbsp;&nbsp;&nbsp;</a></li>
   
    <li ><a href="view.php" class="checked">&nbsp;&nbsp;View / Edit&nbsp;&nbsp;&nbsp;</a></li>
    <li ><a href="orders.php">&nbsp;&nbsp;Orders&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
    <li><a href="change_password.php">&nbsp;&nbsp;Change Password&nbsp;&nbsp;&nbsp;</a></li>
    <li><a href="logout.php">&nbsp;&nbsp;Logout&nbsp;&nbsp;&nbsp;</a></li>
    
</ul>